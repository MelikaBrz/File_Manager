const animals = {
    Cow: 'Moo',
    Cat: 'Meow',
    Dog: 'Bark'
  }
  
  delete animals["Dog"];
  
  console.log(animals);